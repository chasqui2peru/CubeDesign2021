%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cargamos los datos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load("main.mat");
load("BUS_SIGNAL.mat");

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SIMULACIÓN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
find_system('Name','behmodel'); %buscamos modelo
open_system('behmodel'); % abrimos modelo
set_param('behmodel','SimulationCommand','Start'); %corremos el programa


