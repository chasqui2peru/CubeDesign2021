#include "rt_logging_mmi.h"
#include "ADCS_comportamento_v6_desafio_capi.h"
#include <math.h>
#include "ADCS_comportamento_v6_desafio.h"
#include "ADCS_comportamento_v6_desafio_private.h"
#include "ADCS_comportamento_v6_desafio_dt.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 2 , & stopRequested ) ; }
rtExtModeShutdown ( 2 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 1 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 1 ; int_T gbl_raccel_NumST = 3 ; const char_T
* gbl_raccel_Version = "9.4 (R2020b) 29-Jul-2020" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes (
SimStruct * S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#define a0wf2asxvb (3U)
#define boepzua0nw (-1)
#define dpydec3vad (2U)
#define emrklcq5cy (6U)
#define hsongop4jy (1U)
#define mepyqqm2b1 (4U)
#define mu1d3g2n5q (5U)
B rtB ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS = &
model_S ; void MdlInitialize ( void ) { rtDW . cl0sirwlrg = boepzua0nw ; rtDW
. oljx1yrr3j = 0U ; rtDW . blm5neaw3j = 0U ; } void MdlStart ( void ) { {
bool externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { FWksInfo * fromwksInfo ; if ( ( fromwksInfo = ( FWksInfo * ) calloc ( 1 ,
sizeof ( FWksInfo ) ) ) == ( NULL ) ) { ssSetErrorStatus ( rtS ,
"from workspace STRING(Name) memory allocation error" ) ; } else {
fromwksInfo -> origWorkspaceVarName =
"Simulink.signaleditorblock.SimulationData.getData('48.0006103515625','1')" ;
fromwksInfo -> origDataTypeId = 0 ; fromwksInfo -> origIsComplex = 0 ;
fromwksInfo -> origWidth = 12 ; fromwksInfo -> origElSize = sizeof ( real_T )
; fromwksInfo -> data = ( void * ) rtP . fromWS_Signal1_Data0 ; fromwksInfo
-> nDataPoints = 73 ; fromwksInfo -> time = ( double * ) rtP .
fromWS_Signal1_Time0 ; rtDW . buqra43nqg . TimePtr = fromwksInfo -> time ;
rtDW . buqra43nqg . DataPtr = fromwksInfo -> data ; rtDW . buqra43nqg .
RSimInfoPtr = fromwksInfo ; ssCachePointer ( rtS , & ( rtDW . buqra43nqg .
TimePtr ) ) ; ssCachePointer ( rtS , & ( rtDW . buqra43nqg . DataPtr ) ) ;
ssCachePointer ( rtS , & ( rtDW . buqra43nqg . RSimInfoPtr ) ) ; } rtDW .
ogjavfdbsg . PrevIndex = 0 ; } MdlInitialize ( ) ; } void MdlOutputs ( int_T
tid ) { rtB . a30tmj0klx = ssGetT ( rtS ) ; if ( rtP .
flag_start_CurrentSetting == 1 ) { rtB . jsh0j50ymd = rtP . Constant_Value ;
} else { rtB . jsh0j50ymd = rtP . Constant1_Value ; } { real_T t =
ssGetTaskTime ( rtS , 0 ) ; real_T * pTimeValues = ( real_T * ) rtDW .
buqra43nqg . TimePtr ; real_T * pDataValues = ( real_T * ) rtDW . buqra43nqg
. DataPtr ; int numPoints , lastPoint ; FWksInfo * fromwksInfo = ( FWksInfo *
) rtDW . buqra43nqg . RSimInfoPtr ; numPoints = fromwksInfo -> nDataPoints ;
lastPoint = numPoints - 1 ; if ( t < pTimeValues [ 0 ] ) { { int_T elIdx ;
for ( elIdx = 0 ; elIdx < 12 ; ++ elIdx ) { ( & rtB . ex3xinf4qw [ 0 ] ) [
elIdx ] = 0.0 ; } } } else if ( t == pTimeValues [ lastPoint ] ) { { int_T
elIdx ; for ( elIdx = 0 ; elIdx < 12 ; ++ elIdx ) { ( & rtB . ex3xinf4qw [ 0
] ) [ elIdx ] = pDataValues [ lastPoint ] ; pDataValues += numPoints ; } } }
else if ( t > pTimeValues [ lastPoint ] ) { { int_T elIdx ; for ( elIdx = 0 ;
elIdx < 12 ; ++ elIdx ) { ( & rtB . ex3xinf4qw [ 0 ] ) [ elIdx ] = 0.0 ; } }
} else { int_T currTimeIndex = rtDW . ogjavfdbsg . PrevIndex ; if ( t <
pTimeValues [ currTimeIndex ] ) { while ( t < pTimeValues [ currTimeIndex ] )
{ currTimeIndex -- ; } } else { while ( t >= pTimeValues [ currTimeIndex + 1
] ) { currTimeIndex ++ ; } } { int_T elIdx ; for ( elIdx = 0 ; elIdx < 12 ;
++ elIdx ) { ( & rtB . ex3xinf4qw [ 0 ] ) [ elIdx ] = pDataValues [
currTimeIndex ] ; pDataValues += numPoints ; } } rtDW . ogjavfdbsg .
PrevIndex = currTimeIndex ; } } rtB . dm5jzmq1qe = muDoubleScalarSin ( rtP .
SineWave_Freq * ssGetTaskTime ( rtS , 0 ) + rtP . SineWave_Phase ) * rtP .
SineWave_Amp + rtP . SineWave_Bias ; rtDW . cl0sirwlrg = boepzua0nw ; if (
rtDW . oljx1yrr3j == 0U ) { rtDW . oljx1yrr3j = 1U ; rtDW . blm5neaw3j =
mu1d3g2n5q ; rtB . pmjucmi50m = 0.0 ; } else { switch ( rtDW . blm5neaw3j ) {
case hsongop4jy : if ( rtB . ex3xinf4qw [ 10 ] == 1.0 ) { rtDW . blm5neaw3j =
mepyqqm2b1 ; rtB . pmjucmi50m = 1.0 ; } else if ( ( rtB . ex3xinf4qw [ 10 ]
== 0.0 ) && ( rtB . a30tmj0klx - rtDW . o0b1qtb0hc > 4.0 ) ) { rtDW .
blm5neaw3j = emrklcq5cy ; rtB . pmjucmi50m = 4.0 ; } else { rtB . pmjucmi50m
= 5.0 ; rtDW . o0b1qtb0hc = rtB . a30tmj0klx ; } break ; case dpydec3vad :
rtB . pmjucmi50m = 3.0 ; break ; case a0wf2asxvb : rtB . pmjucmi50m = 2.0 ;
break ; case mepyqqm2b1 : if ( rtB . ex3xinf4qw [ 11 ] == 1.0 ) { rtDW .
blm5neaw3j = hsongop4jy ; rtB . pmjucmi50m = 5.0 ; rtDW . o0b1qtb0hc = rtB .
a30tmj0klx ; } else { rtB . pmjucmi50m = 1.0 ; } break ; case mu1d3g2n5q : if
( rtB . jsh0j50ymd == 0.0 ) { rtDW . blm5neaw3j = mu1d3g2n5q ; rtB .
pmjucmi50m = 0.0 ; } else if ( rtB . a30tmj0klx >= 5.0 ) { rtDW . blm5neaw3j
= mepyqqm2b1 ; rtB . pmjucmi50m = 1.0 ; } else { rtB . pmjucmi50m = 0.0 ; }
break ; default : rtB . pmjucmi50m = 4.0 ; break ; } } UNUSED_PARAMETER ( tid
) ; } void MdlOutputsTID2 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlUpdate ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void MdlUpdateTID2 (
int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void MdlTerminate ( void ) {
rt_FREE ( rtDW . buqra43nqg . RSimInfoPtr ) ; } void MdlInitializeSizes (
void ) { ssSetNumContStates ( rtS , 0 ) ; ssSetNumY ( rtS , 0 ) ; ssSetNumU (
rtS , 0 ) ; ssSetDirectFeedThrough ( rtS , 0 ) ; ssSetNumSampleTimes ( rtS ,
2 ) ; ssSetNumBlocks ( rtS , 12 ) ; ssSetNumBlockIO ( rtS , 5 ) ;
ssSetNumBlockParams ( rtS , 956 ) ; } void MdlInitializeSampleTimes ( void )
{ ssSetSampleTime ( rtS , 0 , 0.0 ) ; ssSetSampleTime ( rtS , 1 , 1.0 ) ;
ssSetOffsetTime ( rtS , 0 , 0.0 ) ; ssSetOffsetTime ( rtS , 1 , 0.0 ) ; }
void raccel_set_checksum ( ) { ssSetChecksumVal ( rtS , 0 , 3713786248U ) ;
ssSetChecksumVal ( rtS , 1 , 2202792182U ) ; ssSetChecksumVal ( rtS , 2 ,
1386507916U ) ; ssSetChecksumVal ( rtS , 3 , 1015178656U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; ( void ) memset ( ( char * ) rtS , 0 ,
sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0 , sizeof
( struct _ssMdlInfo ) ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ;
ssSetExecutionInfo ( rtS , executionInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ssSetWorkSizeInBytes ( rtS , sizeof ( rtB ) ,
"BlockIO" ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof ( B ) ) ; }
{ void * dwork = ( void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ;
ssSetWorkSizeInBytes ( rtS , sizeof ( rtDW ) , "DWork" ) ; ( void ) memset (
dwork , 0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void )
memset ( ( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ;
ssSetModelMappingInfo ( rtS , & dtInfo ) ; dtInfo . numDataTypes = 14 ;
dtInfo . dataTypeSizes = & rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = &
rtDataTypeNames [ 0 ] ; dtInfo . BTransTable = & rtBTransTable ; dtInfo .
PTransTable = & rtPTransTable ; dtInfo . dataTypeInfoTable =
rtDataTypeInfoTable ; } ADCS_comportamento_v6_desafio_InitializeDataMapInfo (
) ; ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS )
; ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"ADCS_comportamento_v6_desafio" ) ; ssSetPath ( rtS ,
"ADCS_comportamento_v6_desafio" ) ; ssSetTStart ( rtS , 0.0 ) ; ssSetTFinal (
rtS , 160.0 ) ; ssSetStepSize ( rtS , 1.0 ) ; ssSetFixedStepSize ( rtS , 1.0
) ; { static RTWLogInfo rt_DataLoggingInfo ; rt_DataLoggingInfo .
loggingInterval = NULL ; ssSetRTWLogInfo ( rtS , & rt_DataLoggingInfo ) ; } {
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
ssSolverInfo slvrInfo ; ssSetSolverInfo ( rtS , & slvrInfo ) ;
ssSetSolverName ( rtS , "FixedStepDiscrete" ) ; ssSetVariableStepSolver ( rtS
, 0 ) ; ssSetSolverConsistencyChecking ( rtS , 0 ) ;
ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ; ssSetSolverRobustResetMethod (
rtS , 0 ) ; ssSetSolverStateProjection ( rtS , 0 ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetTNextTid ( rtS , INT_MIN ) ;
ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 0 ) ; } ssSetChecksumVal ( rtS , 0 ,
3713786248U ) ; ssSetChecksumVal ( rtS , 1 , 2202792182U ) ; ssSetChecksumVal
( rtS , 2 , 1386507916U ) ; ssSetChecksumVal ( rtS , 3 , 1015178656U ) ; {
static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static
RTWExtModeInfo rt_ExtModeInfo ; static const sysRanDType * systemRan [ 2 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) ,
& ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo
( rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS
) , ssGetTPtr ( rtS ) ) ; } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 2 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID2 ( tid ) ; }
