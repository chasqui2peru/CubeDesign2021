#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "ADCS_comportamento_v6_desafio.h"
#define GRTINTERFACE 1
#endif
