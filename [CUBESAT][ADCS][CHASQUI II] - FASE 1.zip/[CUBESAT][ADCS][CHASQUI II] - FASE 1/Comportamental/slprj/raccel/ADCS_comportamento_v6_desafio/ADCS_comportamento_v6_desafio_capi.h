#ifndef RTW_HEADER_ADCS_comportamento_v6_desafio_capi_h
#define RTW_HEADER_ADCS_comportamento_v6_desafio_capi_h
#include "ADCS_comportamento_v6_desafio.h"
extern void ADCS_comportamento_v6_desafio_InitializeDataMapInfo ( void ) ;
#endif
