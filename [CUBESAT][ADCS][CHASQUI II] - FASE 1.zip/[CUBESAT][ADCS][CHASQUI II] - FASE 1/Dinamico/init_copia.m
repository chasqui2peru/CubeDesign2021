clc
clear
Simulink.sdi.clear
%% Inicialização
load('parametros.mat');
open('Desafio_ADCS_CDVII_copia.slx');

%Momento de Inercia roda de reação de um Cubesat (Study and Design of the attitude control of a cubesat 1U based on reaction wheels)
Jr = 36e-6 %Kg.m²
w_rr_max = 0.10472*5000; %velocidade de rotação maxima da RR em rad/2 (5000 rpm)
L_rr_max = w_rr_max*Jr; %momento angular maximo da roda de reação (N*m*s)
I_rr_max = 0.5;
N_rr_max = Km*I_rr_max;%torque máximo depende do parametro Km e da corrente
T = 5; %tensão roda de reação
%Momento de Inercia total satelite (Study and Design of the attitude control of a cubesat 1U based on reaction wheels)
massa_sat = 1.3 %Kilos
d = 0.1 %metros
% J = eye(3)*((massa_sat*((d^2)/6)))
J = eye(3)*((massa_sat*((d^2)/6))+Jr)

vel_ang_inicial = [6e-3 6e-3 6e-3]';
%vel_ang_inicial = [0 0 0]';
mag_ref = [2 -5 3]';
sol_ref = [5 -1 1]';

%Magneto torque
A = 9.03e-3;
N = 400;
Imag_max = 8.3e-3;

%Simulação
sample_time = 1;


