clearvars
load('parametros_EPS.mat')
open('EPS.slx')
sim('EPS.slx')
out = ans;